package shared;

public interface IRequestHandler {
	public ResponseDescriptor handleRequest(RequestDescriptor request);
}
