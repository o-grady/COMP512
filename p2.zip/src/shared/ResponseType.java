package shared;

public enum ResponseType {
	INTEGER,
	BOOLEAN,
	STRING,
	ERROR,
	ABORT
}
