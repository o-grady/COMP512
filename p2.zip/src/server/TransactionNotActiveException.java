package server;

public class TransactionNotActiveException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7040826568707379452L;

}
