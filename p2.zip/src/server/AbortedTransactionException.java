package server;

public class AbortedTransactionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1591161845922784105L;

}
