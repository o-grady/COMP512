package middleware;

public enum ServerMode {
	CAR,
	FLIGHT,
	ROOM,
	CUSTOMER
}